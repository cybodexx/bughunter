import { Link, useLocation } from "wouter";
import { Search, History, Rocket, BookOpen, AlertTriangle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const navItems = [
  { href: "/", icon: Search, label: "Scanner" },
  { href: "/history", icon: History, label: "Scan History" },
  { href: "/attack-guide", icon: BookOpen, label: "Attack Guide" },
  { href: "/deploy", icon: Rocket, label: "Deploy" },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-56 bg-secondary border-r border-gray-700 min-h-screen" data-testid="sidebar">
      <nav className="p-4 space-y-1">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                isActive
                  ? 'bg-accent text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
              data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <item.icon size={18} />
              <span className="text-sm">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Warning Section */}
      <div className="mx-4 mt-6">
        <Card className="bg-red-900 bg-opacity-20 border-red-500">
          <CardContent className="p-3">
            <div className="flex items-start space-x-2">
              <AlertTriangle className="text-red-400 flex-shrink-0 mt-0.5" size={14} />
              <div className="text-xs">
                <p className="font-semibold text-red-400 mb-1" data-testid="warning-title">Authorized Use Only</p>
                <p className="text-gray-300 leading-relaxed" data-testid="warning-text">
                  Only test websites you own or have explicit permission to test. Unauthorized testing is illegal.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </aside>
  );
}
